class Saving {
  final int? id;
  final int ownerId;
  final double amount;
  final String type;
  final String? description;
  final String date;
  final String? createdAt;

  Saving({
    this.id,
    required this.ownerId,
    required this.amount,
    required this.type,
    this.description,
    required this.date,
    this.createdAt,
  });

  factory Saving.fromMap(Map<String, dynamic> json) => Saving(
    id: json['id'],
    ownerId: json['owner_id'],
    amount: json['amount'],
    type: json['type'],
    description: json['description'],
    date: json['date'],
    createdAt: json['created_at'],
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'owner_id': ownerId,
    'amount': amount,
    'type': type,
    'description': description,
    'date': date,
    'created_at': createdAt,
  };
}
