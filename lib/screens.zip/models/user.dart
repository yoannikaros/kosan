class User {
  final int? id;
  final int? ownerId;
  final String username;
  final String password;
  final String role;
  final String? createdAt;

  User({
    this.id,
    this.ownerId,
    required this.username,
    required this.password,
    this.role = 'tenant',
    this.createdAt,
  });

  factory User.fromMap(Map<String, dynamic> json) => User(
    id: json['id'],
    ownerId: json['owner_id'],
    username: json['username'],
    password: json['password'],
    role: json['role'],
    createdAt: json['created_at'],
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'owner_id': ownerId,
    'username': username,
    'password': password,
    'role': role,
    'created_at': createdAt,
  };
}
