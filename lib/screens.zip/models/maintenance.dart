class Maintenance {
  final int? id;
  final int roomId;
  final String description;
  final double? cost;
  final String maintenanceDate;
  final String? createdAt;

  Maintenance({
    this.id,
    required this.roomId,
    required this.description,
    this.cost,
    required this.maintenanceDate,
    this.createdAt,
  });

  factory Maintenance.fromMap(Map<String, dynamic> json) => Maintenance(
    id: json['id'],
    roomId: json['room_id'],
    description: json['description'],
    cost: json['cost'],
    maintenanceDate: json['maintenance_date'],
    createdAt: json['created_at'],
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'room_id': roomId,
    'description': description,
    'cost': cost,
    'maintenance_date': maintenanceDate,
    'created_at': createdAt,
  };
}
