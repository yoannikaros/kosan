class Transaction {
  final int? id;
  final int ownerId;
  final String type;
  final String? category;
  final double amount;
  final String? description;
  final String transactionDate;
  final String? createdAt;

  Transaction({
    this.id,
    required this.ownerId,
    required this.type,
    this.category,
    required this.amount,
    this.description,
    required this.transactionDate,
    this.createdAt,
  });

  factory Transaction.fromMap(Map<String, dynamic> json) => Transaction(
    id: json['id'],
    ownerId: json['owner_id'],
    type: json['type'],
    category: json['category'],
    amount: json['amount'],
    description: json['description'],
    transactionDate: json['transaction_date'],
    createdAt: json['created_at'],
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'owner_id': ownerId,
    'type': type,
    'category': category,
    'amount': amount,
    'description': description,
    'transaction_date': transactionDate,
    'created_at': createdAt,
  };
}
