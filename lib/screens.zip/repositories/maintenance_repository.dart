import 'package:kosan/helpers/database_helper.dart';
import 'package:kosan/models/maintenance.dart';

class MaintenanceRepository {
  final dbHelper = DatabaseHelper.instance;

  Future<int> insertMaintenance(Maintenance maintenance) async {
    return await dbHelper.insert('maintenance', maintenance.toMap());
  }

  Future<List<Maintenance>> getAllMaintenance() async {
    final List<Map<String, dynamic>> maps = await dbHelper.queryAllRows('maintenance');
    return List.generate(maps.length, (i) {
      return Maintenance.fromMap(maps[i]);
    });
  }

  Future<List<Maintenance>> getMaintenanceByRoomId(int roomId) async {
    final List<Map<String, dynamic>> maps = await dbHelper.queryWhere(
      'maintenance',
      'room_id = ?',
      [roomId],
    );
    return List.generate(maps.length, (i) {
      return Maintenance.fromMap(maps[i]);
    });
  }

  Future<Maintenance?> getMaintenanceById(int id) async {
    final List<Map<String, dynamic>> maps = await dbHelper.queryWhere(
      'maintenance',
      'id = ?',
      [id],
    );
    if (maps.isNotEmpty) {
      return Maintenance.fromMap(maps.first);
    }
    return null;
  }

  Future<int> updateMaintenance(Maintenance maintenance) async {
    return await dbHelper.update(
      'maintenance',
      maintenance.toMap(),
      'id = ?',
      [maintenance.id],
    );
  }

  Future<int> deleteMaintenance(int id) async {
    return await dbHelper.delete(
      'maintenance',
      'id = ?',
      [id],
    );
  }
}
