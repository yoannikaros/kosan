import 'package:kosan/helpers/database_helper.dart';
import 'package:kosan/models/saving.dart';

class SavingRepository {
  final dbHelper = DatabaseHelper.instance;

  Future<int> insertSaving(Saving saving) async {
    return await dbHelper.insert('savings', saving.toMap());
  }

  Future<List<Saving>> getAllSavings() async {
    final List<Map<String, dynamic>> maps = await dbHelper.queryAllRows('savings');
    return List.generate(maps.length, (i) {
      return Saving.fromMap(maps[i]);
    });
  }

  Future<List<Saving>> getSavingsByOwnerId(int ownerId) async {
    final List<Map<String, dynamic>> maps = await dbHelper.queryWhere(
      'savings',
      'owner_id = ?',
      [ownerId],
    );
    return List.generate(maps.length, (i) {
      return Saving.fromMap(maps[i]);
    });
  }

  Future<List<Saving>> getSavingsByType(int ownerId, String type) async {
    final List<Map<String, dynamic>> maps = await dbHelper.queryWhere(
      'savings',
      'owner_id = ? AND type = ?',
      [ownerId, type],
    );
    return List.generate(maps.length, (i) {
      return Saving.fromMap(maps[i]);
    });
  }

  Future<Saving?> getSavingById(int id) async {
    final List<Map<String, dynamic>> maps = await dbHelper.queryWhere(
      'savings',
      'id = ?',
      [id],
    );
    if (maps.isNotEmpty) {
      return Saving.fromMap(maps.first);
    }
    return null;
  }

  Future<int> updateSaving(Saving saving) async {
    return await dbHelper.update(
      'savings',
      saving.toMap(),
      'id = ?',
      [saving.id],
    );
  }

  Future<int> deleteSaving(int id) async {
    return await dbHelper.delete(
      'savings',
      'id = ?',
      [id],
    );
  }
}
