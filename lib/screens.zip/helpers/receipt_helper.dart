import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_pos_printer_platform_image_3/flutter_pos_printer_platform_image_3.dart';
import 'package:esc_pos_utils_updated/esc_pos_utils_updated.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:kosan/models/payment.dart';
import 'package:kosan/models/rental.dart';
import 'package:kosan/models/room.dart';
import 'package:kosan/models/tenant.dart';
import 'package:kosan/models/setting.dart';

class ReceiptHelper {
  static final _dateFormat = DateFormat('dd/MM/yyyy');
  static final _currencyFormat = NumberFormat.currency(
    locale: 'id',
    symbol: 'Rp ',
    decimalDigits: 0,
  );

  // Membuat dokumen PDF dari data struk
  static Future<Uint8List> generatePdf({
    required Payment payment,
    required Rental? rental,
    required Room? room,
    required Tenant? tenant,
    required Setting? setting,
  }) async {
    try {
    // Muat font
    pw.Font? ttf;
    pw.Font? ttfBold;
    
    try {
      final fontData = await rootBundle.load("assets/fonts/Poppins-Regular.ttf");
      ttf = pw.Font.ttf(fontData);
      
      final fontBold = await rootBundle.load("assets/fonts/Poppins-Bold.ttf");
      ttfBold = pw.Font.ttf(fontBold);
    } catch (e) {
      // Gunakan font default jika font kustom tidak tersedia
      ttf = null;
      ttfBold = null;
    }

    // Buat dokumen PDF
    final pdf = pw.Document();

    // Tambahkan halaman
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a5,
        build: (pw.Context context) {
          return pw.Container(
            padding: const pw.EdgeInsets.all(16),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                // Header
                pw.Center(
                  child: pw.Column(
                    children: [
                      pw.Text(
                        setting?.businessName ?? 'Manajemen Kost',
                        style: pw.TextStyle(
                          font: ttfBold,
                          fontSize: 18,
                          fontWeight: pw.FontWeight.bold,
                        ),
                        textAlign: pw.TextAlign.center,
                      ),
                      pw.SizedBox(height: 4),
                      if (setting?.noteHeader != null && setting!.noteHeader!.isNotEmpty)
                        pw.Text(
                          setting.noteHeader!,
                          style: pw.TextStyle(font: ttf, fontSize: 10),
                          textAlign: pw.TextAlign.center,
                        ),
                    ],
                  ),
                ),
                pw.Divider(thickness: 2),
                
                // Informasi Pembayaran
                pw.Center(
                  child: pw.Text(
                    'STRUK PEMBAYARAN',
                    style: pw.TextStyle(
                      font: ttfBold,
                      fontSize: 14,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                ),
                pw.SizedBox(height: 16),
                
                // Detail Pembayaran
                _buildPdfDetailRow(
                  'No. Pembayaran', 
                  '#${payment.id ?? "New"}',

                ),
                _buildPdfDetailRow(
                  'Tanggal', 
                  _dateFormat.format(DateTime.parse(payment.paymentDate)),

                ),
                _buildPdfDetailRow(
                  'Jumlah', 
                  _currencyFormat.format(payment.amount),

                ),
                if (payment.paymentMethod != null && payment.paymentMethod!.isNotEmpty)
                  _buildPdfDetailRow(
                    'Metode Pembayaran', 
                    payment.paymentMethod!
                  ),
                
                pw.Divider(),
                
                // Detail Kamar & Penyewa
                if (room != null)
                  _buildPdfDetailRow(
                    'Kamar', 
                    'Kamar ${room.roomNumber}',
                    ttf,
                    ttfBold,
                  ),
                if (tenant != null)
                  _buildPdfDetailRow(
                    'Penyewa', 
                    tenant.name,
                    ttf,
                    ttfBold,
                  ),
                if (rental != null) ...[
                  _buildPdfDetailRow(
                    'Periode Sewa', 
                    '${_dateFormat.format(DateTime.parse(rental.startDate))} - ${_dateFormat.format(DateTime.parse(rental.endDate))}',
                    ttf,
                    ttfBold,
                  ),
                  _buildPdfDetailRow(
                    'Harga Sewa', 
                    _currencyFormat.format(rental.rentPrice)
                  );
                ],
                
                if (payment.note != null && payment.note!.isNotEmpty) ...[
                  pw.Divider(),
                  _buildPdfDetailRow(
                    'Catatan', 
                    payment.note!,
                    ttf,
                    ttfBold,
                  ),
                ],
                
                pw.Divider(thickness: 2),
                
                // Footer
                if (setting?.noteFooter != null && setting!.noteFooter!.isNotEmpty)
                  pw.Center(
                    child: pw.Text(
                      setting.noteFooter!,
                      style: pw.TextStyle(font: ttf, fontSize: 10),
                      textAlign: pw.TextAlign.center,
                    ),
                  ),
                
                pw.SizedBox(height: 8),
                pw.Center(
                  child: pw.Text(
                    'Terima Kasih',
                    style: pw.TextStyle(
                      font: ttfBold,
                      fontSize: 12,
                      fontWeight: pw.FontWeight.bold,
                    ),
                    textAlign: pw.TextAlign.center,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );

    return pdf.save();
  } catch (e) {
    throw Exception('Gagal membuat PDF: ${e.toString()}');
  }
}

  // Helper untuk membuat baris detail di PDF
  static pw.Widget _buildPdfDetailRow(
    String label, 
    String value, 
    pw.Font font, 
    pw.Font boldFont
  ) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 4.0),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.SizedBox(
            width: 120,
            child: pw.Text(
              label,
              style: pw.TextStyle(
                font: boldFont,
              ),
            ),
          ),
          pw.Text(' : '),
          pw.Expanded(
            child: pw.Text(
              value,
              style: pw.TextStyle(
                font: font,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Menyimpan PDF ke penyimpanan lokal
  static Future<File> savePdf(Uint8List pdfBytes, String fileName) async {
  try {
    // Minta izin penyimpanan
    final status = await Permission.storage.request();
    if (!status.isGranted) {
      // Coba gunakan direktori aplikasi jika izin tidak diberikan
      final directory = await getApplicationDocumentsDirectory();
      final filePath = '${directory.path}/$fileName';
      final file = File(filePath);
      
      // Tulis file
      await file.writeAsBytes(pdfBytes);
      return file;
    }

    // Jika izin diberikan, gunakan direktori dokumen
    final directory = await getApplicationDocumentsDirectory();
    final filePath = '${directory.path}/$fileName';
    final file = File(filePath);
    
    // Tulis file
    await file.writeAsBytes(pdfBytes);
    return file;
  } catch (e) {
    throw Exception('Gagal menyimpan PDF: ${e.toString()}');
  }
}

  // Mencetak ke printer thermal
  static Future<void> printThermal({
  required Payment payment,
  required Rental? rental,
  required Room? room,
  required Tenant? tenant,
  required Setting? setting,
}) async {
  try {
    // Inisialisasi printer
    final printerManager = PrinterManager.instance;
    
    // Dapatkan daftar printer yang tersedia
    final devices = await printerManager.discoverPrinters();
    
    if (devices.isEmpty) {
      throw Exception('Tidak ada printer yang ditemukan. Pastikan printer thermal terhubung dan diaktifkan.');
    }
    
    // Tampilkan dialog pemilihan printer jika ada lebih dari satu printer
    // Catatan: Implementasi dialog pemilihan printer seharusnya dilakukan di UI, bukan di helper
    final printer = devices.first;
    
    // Buat generator ESC/POS
    final profile = await CapabilityProfile.load();
    final generator = Generator(PaperSize.mm80, profile);
    
    // Buat konten struk
    List<int> bytes = [];
    
    // Header
    bytes += generator.text(
      setting?.businessName ?? 'Manajemen Kost',
      styles: const PosStyles(
        align: PosAlign.center,
        bold: true,
        height: PosTextSize.size2,
        width: PosTextSize.size2,
      ),
    );
    
    if (setting?.noteHeader != null && setting!.noteHeader!.isNotEmpty) {
      bytes += generator.text(
        setting.noteHeader!,
        styles: const PosStyles(align: PosAlign.center),
      );
    }
    
    bytes += generator.hr();
    bytes += generator.text(
      'STRUK PEMBAYARAN',
      styles: const PosStyles(align: PosAlign.center, bold: true),
    );
    bytes += generator.text('');
    
    // Detail Pembayaran
    bytes += generator.row([
      PosColumn(
        text: 'No. Pembayaran',
        width: 6,
        styles: const PosStyles(bold: true),
      ),
      PosColumn(
        text: ': #${payment.id ?? "New"}',
        width: 6,
      ),
    ]);
    
    bytes += generator.row([
      PosColumn(
        text: 'Tanggal',
        width: 6,
        styles: const PosStyles(bold: true),
      ),
      PosColumn(
        text: ': ${_dateFormat.format(DateTime.parse(payment.paymentDate))}',
        width: 6,
      ),
    ]);
    
    // Pastikan teks tidak terlalu panjang untuk printer thermal
    final amountText = _currencyFormat.format(payment.amount);
    bytes += generator.row([
      PosColumn(
        text: 'Jumlah',
        width: 6,
        styles: const PosStyles(bold: true),
      ),
      PosColumn(
        text: ': ${amountText.length > 18 ? amountText.substring(0, 18) : amountText}',
        width: 6,
      ),
    ]);
    
    if (payment.paymentMethod != null && payment.paymentMethod!.isNotEmpty) {
      final methodText = payment.paymentMethod!;
      bytes += generator.row([
        PosColumn(
          text: 'Metode',
          width: 6,
          styles: const PosStyles(bold: true),
        ),
        PosColumn(
          text: ': ${methodText.length > 18 ? methodText.substring(0, 18) : methodText}',
          width: 6,
        ),
      ]);
    }
    
    bytes += generator.hr();
    
    // Detail Kamar & Penyewa
    if (room != null) {
      bytes += generator.row([
        PosColumn(
          text: 'Kamar',
          width: 6,
          styles: const PosStyles(bold: true),
        ),
        PosColumn(
          text: ': Kamar ${room.roomNumber}',
          width: 6,
        ),
      ]);
    }
    
    if (tenant != null) {
      final tenantName = tenant.name;
      bytes += generator.row([
        PosColumn(
          text: 'Penyewa',
          width: 6,
          styles: const PosStyles(bold: true),
        ),
        PosColumn(
          text: ': ${tenantName.length > 18 ? tenantName.substring(0, 18) : tenantName}',
          width: 6,
        ),
      ]);
    }
    
    if (rental != null) {
      final startDate = _dateFormat.format(DateTime.parse(rental.startDate));
      final endDate = _dateFormat.format(DateTime.parse(rental.endDate));
      bytes += generator.row([
        PosColumn(
          text: 'Periode',
          width: 6,
          styles: const PosStyles(bold: true),
        ),
        PosColumn(
          text: ': $startDate -',
          width: 6,
        ),
      ]);
      bytes += generator.row([
        PosColumn(
          text: '',
          width: 6,
        ),
        PosColumn(
          text: '  $endDate',
          width: 6,
        ),
      ]);
      
      final rentPrice = _currencyFormat.format(rental.rentPrice);
      bytes += generator.row([
        PosColumn(
          text: 'Harga Sewa',
          width: 6,
          styles: const PosStyles(bold: true),
        ),
        PosColumn(
          text: ': ${rentPrice.length > 18 ? rentPrice.substring(0, 18) : rentPrice}',
          width: 6,
        ),
      ]);
    }
    
    if (payment.note != null && payment.note!.isNotEmpty) {
      bytes += generator.hr();
      
      // Pecah catatan yang panjang menjadi beberapa baris
      final note = payment.note!;
      if (note.length > 30) {
        bytes += generator.row([
          PosColumn(
            text: 'Catatan',
            width: 6,
            styles: const PosStyles(bold: true),
          ),
          PosColumn(
            text: ': ${note.substring(0, 30)}',
            width: 6,
          ),
        ]);
        
        int start = 30;
        while (start < note.length) {
          int end = start + 30;
          if (end > note.length) end = note.length;
          
          bytes += generator.row([
            PosColumn(
              text: '',
              width: 6,
            ),
            PosColumn(
              text: '  ${note.substring(start, end)}',
              width: 6,
            ),
          ]);
          
          start = end;
        }
      } else {
        bytes += generator.row([
          PosColumn(
            text: 'Catatan',
            width: 6,
            styles: const PosStyles(bold: true),
          ),
          PosColumn(
            text: ': $note',
            width: 6,
          ),
        ]);
      }
    }
    
    bytes += generator.hr();
    
    // Footer
    if (setting?.noteFooter != null && setting!.noteFooter!.isNotEmpty) {
      bytes += generator.text(
        setting.noteFooter!,
        styles: const PosStyles(align: PosAlign.center),
      );
    }
    
    bytes += generator.text(
      'Terima Kasih',
      styles: const PosStyles(align: PosAlign.center, bold: true),
    );
    
    bytes += generator.cut();
    
    // Cetak ke printer
    try {
      await printerManager.connect(
        type: printer.type,
        model: printer.name,
        address: printer.address,
      );
      
      await printerManager.send(type: printer.type, bytes: bytes);
      await printerManager.disconnect(type: printer.type);
    } catch (e) {
      throw Exception('Gagal mencetak ke printer: ${e.toString()}');
    }
    
  } catch (e) {
    rethrow;
  }
}
}
