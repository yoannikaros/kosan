import 'package:flutter/material.dart';
import 'package:kosan/models/tenant.dart';
import 'package:kosan/models/user.dart';
import 'package:kosan/repositories/tenant_repository.dart';
import 'package:kosan/repositories/user_repository.dart';

class TenantsScreen extends StatefulWidget {
  final User user;

  const TenantsScreen({Key? key, required this.user}) : super(key: key);

  @override
  State<TenantsScreen> createState() => _TenantsScreenState();
}

class _TenantsScreenState extends State<TenantsScreen> {
  final _tenantRepository = TenantRepository();
  final _userRepository = UserRepository();
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _identityNumberController = TextEditingController();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  
  List<Tenant> _tenants = [];
  bool _isLoading = true;
  Tenant? _selectedTenant;
  bool _isNewUser = true;

  @override
  void initState() {
    super.initState();
    _loadTenants();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _identityNumberController.dispose();
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _loadTenants() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      final tenants = await _tenantRepository.getAllTenants();
      setState(() {
        _tenants = tenants;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _resetForm() {
    _selectedTenant = null;
    _nameController.clear();
    _emailController.clear();
    _phoneController.clear();
    _identityNumberController.clear();
    _usernameController.clear();
    _passwordController.clear();
    _isNewUser = true;
  }

  void _showTenantForm({Tenant? tenant}) {
    _resetForm();
    
    if (tenant != null) {
      _selectedTenant = tenant;
      _nameController.text = tenant.name;
      _emailController.text = tenant.email ?? '';
      _phoneController.text = tenant.phone ?? '';
      _identityNumberController.text = tenant.identityNumber ?? '';
      _isNewUser = false;
    }
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(tenant == null ? 'Tambah Penyewa' : 'Edit Penyewa'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Nama Lengkap',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Nama tidak boleh kosong';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                  ),
                  keyboardType: TextInputType.emailAddress,
                ),
                TextFormField(
                  controller: _phoneController,
                  decoration: const InputDecoration(
                    labelText: 'Nomor Telepon',
                  ),
                  keyboardType: TextInputType.phone,
                ),
                TextFormField(
                  controller: _identityNumberController,
                  decoration: const InputDecoration(
                    labelText: 'Nomor Identitas (KTP)',
                  ),
                ),
                if (_isNewUser) ...[
                  const SizedBox(height: 16),
                  const Divider(),
                  const SizedBox(height: 8),
                  const Text(
                    'Informasi Akun',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  TextFormField(
                    controller: _usernameController,
                    decoration: const InputDecoration(
                      labelText: 'Username',
                    ),
                    validator: (value) {
                      if (_isNewUser && (value == null || value.isEmpty)) {
                        return 'Username tidak boleh kosong';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    controller: _passwordController,
                    decoration: const InputDecoration(
                      labelText: 'Password',
                    ),
                    obscureText: true,
                    validator: (value) {
                      if (_isNewUser && (value == null || value.isEmpty)) {
                        return 'Password tidak boleh kosong';
                      }
                      return null;
                    },
                  ),
                ],
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                try {
                  int? userId;
                  
                  if (_isNewUser) {
                    // Cek apakah username sudah digunakan
                    final existingUser = await _userRepository.getUserByUsername(_usernameController.text);
                    if (existingUser != null) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Username sudah digunakan'),
                          backgroundColor: Colors.red,
                        ),
                      );
                      return;
                    }
                    
                    // Buat user baru
                    final user = User(
                      ownerId: widget.user.ownerId,
                      username: _usernameController.text,
                      password: _passwordController.text,
                      role: 'tenant',
                    );
                    
                    userId = await _userRepository.insertUser(user);
                  }
                  
                  final tenant = Tenant(
                    id: _selectedTenant?.id,
                    userId: userId ?? _selectedTenant?.userId,
                    name: _nameController.text,
                    email: _emailController.text.isNotEmpty ? _emailController.text : null,
                    phone: _phoneController.text.isNotEmpty ? _phoneController.text : null,
                    identityNumber: _identityNumberController.text.isNotEmpty ? _identityNumberController.text : null,
                  );
                  
                  if (_selectedTenant == null) {
                    await _tenantRepository.insertTenant(tenant);
                  } else {
                    await _tenantRepository.updateTenant(tenant);
                  }
                  
                  Navigator.pop(context);
                  _loadTenants();
                  
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        _selectedTenant == null
                            ? 'Penyewa berhasil ditambahkan'
                            : 'Penyewa berhasil diperbarui',
                      ),
                      backgroundColor: Colors.green,
                    ),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Error: ${e.toString()}'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirmation(Tenant tenant) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Penyewa'),
        content: Text('Apakah Anda yakin ingin menghapus penyewa ${tenant.name}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              try {
                await _tenantRepository.deleteTenant(tenant.id!);
                Navigator.pop(context);
                _loadTenants();
                
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Penyewa berhasil dihapus'),
                    backgroundColor: Colors.green,
                  ),
                );
              } catch (e) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Error: ${e.toString()}'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _tenants.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.people,
                        size: 80,
                        color: Colors.grey,
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Belum ada data penyewa',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.grey,
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => _showTenantForm(),
                        child: const Text('Tambah Penyewa'),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: _tenants.length,
                  itemBuilder: (context, index) {
                    final tenant = _tenants[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      child: ListTile(
                        leading: CircleAvatar(
                          child: Text(
                            tenant.name.substring(0, 1).toUpperCase(),
                          ),
                        ),
                        title: Text(
                          tenant.name,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (tenant.phone != null) Text('Telepon: ${tenant.phone}'),
                            if (tenant.email != null) Text('Email: ${tenant.email}'),
                          ],
                        ),
                        trailing: PopupMenuButton(
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              value: 'edit',
                              child: Text('Edit'),
                            ),
                            const PopupMenuItem(
                              value: 'delete',
                              child: Text('Hapus'),
                            ),
                          ],
                          onSelected: (value) {
                            if (value == 'edit') {
                              _showTenantForm(tenant: tenant);
                            } else if (value == 'delete') {
                              _showDeleteConfirmation(tenant);
                            }
                          },
                        ),
                        onTap: () {
                          // Detail penyewa
                        },
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showTenantForm(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
