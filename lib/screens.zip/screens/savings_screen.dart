import 'package:flutter/material.dart';
import 'package:kosan/models/saving.dart';
import 'package:kosan/models/user.dart';
import 'package:kosan/repositories/saving_repository.dart';
import 'package:intl/intl.dart';

class SavingsScreen extends StatefulWidget {
  final User user;

  const SavingsScreen({Key? key, required this.user}) : super(key: key);

  @override
  State<SavingsScreen> createState() => _SavingsScreenState();
}

class _SavingsScreenState extends State<SavingsScreen> {
  final _savingRepository = SavingRepository();
  final _formKey = GlobalKey<FormState>();
  
  List<Saving> _savings = [];
  bool _isLoading = true;
  Saving? _selectedSaving;
  
  String _selectedType = 'deposit';
  final _amountController = TextEditingController();
  final _descriptionController = TextEditingController();
  DateTime _date = DateTime.now();
  
  final _dateFormat = DateFormat('dd/MM/yyyy');
  final _currencyFormat = NumberFormat.currency(
    locale: 'id',
    symbol: 'Rp ',
    decimalDigits: 0,
  );

  @override
  void initState() {
    super.initState();
    _loadSavings();
  }

  @override
  void dispose() {
    _amountController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _loadSavings() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      final savings = await _savingRepository.getAllSavings();
      setState(() {
        _savings = savings;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _resetForm() {
    _selectedSaving = null;
    _selectedType = 'deposit';
    _amountController.clear();
    _descriptionController.clear();
    _date = DateTime.now();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    
    if (picked != null) {
      setState(() {
        _date = picked;
      });
    }
  }

  void _showSavingForm({Saving? saving}) {
    _resetForm();
    
    if (saving != null) {
      _selectedSaving = saving;
      _selectedType = saving.type;
      _amountController.text = saving.amount.toString();
      _descriptionController.text = saving.description ?? '';
      _date = DateTime.parse(saving.date);
    }
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(saving == null ? 'Tambah Tabungan' : 'Edit Tabungan'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: _selectedType,
                  decoration: const InputDecoration(
                    labelText: 'Tipe',
                  ),
                  items: const [
                    DropdownMenuItem<String>(
                      value: 'deposit',
                      child: Text('Setoran'),
                    ),
                    DropdownMenuItem<String>(
                      value: 'withdrawal',
                      child: Text('Penarikan'),
                    ),
                  ],
                  onChanged: (value) {
                    setState(() {
                      _selectedType = value!;
                    });
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _amountController,
                  decoration: const InputDecoration(
                    labelText: 'Jumlah',
                    prefixText: 'Rp ',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Jumlah tidak boleh kosong';
                    }
                    if (double.tryParse(value) == null) {
                      return 'Jumlah harus berupa angka';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _descriptionController,
                  decoration: const InputDecoration(
                    labelText: 'Deskripsi',
                  ),
                  maxLines: 2,
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        readOnly: true,
                        decoration: const InputDecoration(
                          labelText: 'Tanggal',
                        ),
                        controller: TextEditingController(
                          text: _dateFormat.format(_date),
                        ),
                        onTap: () => _selectDate(context),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.calendar_today),
                      onPressed: () => _selectDate(context),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                try {
                  final saving = Saving(
                    id: _selectedSaving?.id,
                    ownerId: widget.user.ownerId ?? 0,
                    amount: double.parse(_amountController.text),
                    type: _selectedType,
                    description: _descriptionController.text.isNotEmpty ? _descriptionController.text : null,
                    date: _date.toIso8601String(),
                  );
                  
                  if (_selectedSaving == null) {
                    await _savingRepository.insertSaving(saving);
                  } else {
                    await _savingRepository.updateSaving(saving);
                  }
                  
                  Navigator.pop(context);
                  _loadSavings();
                  
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        _selectedSaving == null
                            ? 'Tabungan berhasil ditambahkan'
                            : 'Tabungan berhasil diperbarui',
                      ),
                      backgroundColor: Colors.green,
                    ),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Error: ${e.toString()}'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirmation(Saving saving) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Tabungan'),
        content: const Text('Apakah Anda yakin ingin menghapus data tabungan ini?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              try {
                await _savingRepository.deleteSaving(saving.id!);
                Navigator.pop(context);
                _loadSavings();
                
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Tabungan berhasil dihapus'),
                    backgroundColor: Colors.green,
                  ),
                );
              } catch (e) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Error: ${e.toString()}'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }

  double _calculateTotalSavings() {
    double total = 0;
    for (var saving in _savings) {
      if (saving.type == 'deposit') {
        total += saving.amount;
      } else {
        total -= saving.amount;
      }
    }
    return total;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Card(
                  margin: const EdgeInsets.all(16),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        const Text(
                          'Total Tabungan',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _currencyFormat.format(_calculateTotalSavings()),
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.blue,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: _savings.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(
                                Icons.savings,
                                size: 80,
                                color: Colors.grey,
                              ),
                              const SizedBox(height: 16),
                              const Text(
                                'Belum ada data tabungan',
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.grey,
                                ),
                              ),
                              const SizedBox(height: 16),
                              ElevatedButton(
                                onPressed: () => _showSavingForm(),
                                child: const Text('Tambah Tabungan'),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          itemCount: _savings.length,
                          itemBuilder: (context, index) {
                            final saving = _savings[index];
                            return Card(
                              margin: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 8,
                              ),
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: saving.type == 'deposit' ? Colors.green : Colors.red,
                                  child: Icon(
                                    saving.type == 'deposit' ? Icons.arrow_downward : Icons.arrow_upward,
                                    color: Colors.white,
                                  ),
                                ),
                                title: Text(
                                  saving.type == 'deposit' ? 'Setoran' : 'Penarikan',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Tanggal: ${_dateFormat.format(DateTime.parse(saving.date))}'),
                                    if (saving.description != null)
                                      Text('Deskripsi: ${saving.description}'),
                                  ],
                                ),
                                trailing: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(
                                      _currencyFormat.format(saving.amount),
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: saving.type == 'deposit' ? Colors.green : Colors.red,
                                      ),
                                    ),
                                    PopupMenuButton(
                                      itemBuilder: (context) => [
                                        const PopupMenuItem(
                                          value: 'edit',
                                          child: Text('Edit'),
                                        ),
                                        const PopupMenuItem(
                                          value: 'delete',
                                          child: Text('Hapus'),
                                        ),
                                      ],
                                      onSelected: (value) {
                                        if (value == 'edit') {
                                          _showSavingForm(saving: saving);
                                        } else if (value == 'delete') {
                                          _showDeleteConfirmation(saving);
                                        }
                                      },
                                    ),
                                  ],
                                ),
                                onTap: () {
                                  // Detail tabungan
                                },
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showSavingForm(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
