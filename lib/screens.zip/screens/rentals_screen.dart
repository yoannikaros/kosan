import 'package:flutter/material.dart';
import 'package:kosan/models/rental.dart';
import 'package:kosan/models/room.dart';
import 'package:kosan/models/tenant.dart';
import 'package:kosan/models/user.dart';
import 'package:kosan/repositories/rental_repository.dart';
import 'package:kosan/repositories/room_repository.dart';
import 'package:kosan/repositories/tenant_repository.dart';
import 'package:intl/intl.dart';

class RentalsScreen extends StatefulWidget {
  final User user;

  const RentalsScreen({Key? key, required this.user}) : super(key: key);

  @override
  State<RentalsScreen> createState() => _RentalsScreenState();
}

class _RentalsScreenState extends State<RentalsScreen> {
  final _rentalRepository = RentalRepository();
  final _roomRepository = RoomRepository();
  final _tenantRepository = TenantRepository();
  final _formKey = GlobalKey<FormState>();
  
  List<Rental> _rentals = [];
  List<Room> _rooms = [];
  List<Tenant> _tenants = [];
  bool _isLoading = true;
  Rental? _selectedRental;
  
  int? _selectedTenantId;
  int? _selectedRoomId;
  DateTime _startDate = DateTime.now();
  DateTime _endDate = DateTime.now().add(const Duration(days: 30));
  final _priceController = TextEditingController();
  
  final _dateFormat = DateFormat('dd/MM/yyyy');
  final _currencyFormat = NumberFormat.currency(
    locale: 'id',
    symbol: 'Rp ',
    decimalDigits: 0,
  );

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _priceController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      final rentals = await _rentalRepository.getAllRentals();
      final rooms = await _roomRepository.getAllRooms();
      final tenants = await _tenantRepository.getAllTenants();
      
      setState(() {
        _rentals = rentals;
        _rooms = rooms;
        _tenants = tenants;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _resetForm() {
    _selectedRental = null;
    _selectedTenantId = null;
    _selectedRoomId = null;
    _startDate = DateTime.now();
    _endDate = DateTime.now().add(const Duration(days: 30));
    _priceController.clear();
  }

  Future<void> _selectDate(BuildContext context, bool isStartDate) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: isStartDate ? _startDate : _endDate,
      firstDate: isStartDate ? DateTime.now() : _startDate,
      lastDate: DateTime(2100),
    );
    
    if (picked != null) {
      setState(() {
        if (isStartDate) {
          _startDate = picked;
          if (_endDate.isBefore(_startDate)) {
            _endDate = _startDate.add(const Duration(days: 30));
          }
        } else {
          _endDate = picked;
        }
      });
    }
  }

  void _showRentalForm({Rental? rental}) {
    _resetForm();
    
    if (rental != null) {
      _selectedRental = rental;
      _selectedTenantId = rental.tenantId;
      _selectedRoomId = rental.roomId;
      _startDate = DateTime.parse(rental.startDate);
      _endDate = DateTime.parse(rental.endDate);
      _priceController.text = rental.rentPrice.toString();
    } else {
      // Default untuk kamar yang dipilih
      if (_rooms.isNotEmpty) {
        _selectedRoomId = _rooms.first.id;
        _priceController.text = _rooms.first.price.toString();
      }
      if (_tenants.isNotEmpty) {
        _selectedTenantId = _tenants.first.id;
      }
    }
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(rental == null ? 'Tambah Kontrak Sewa' : 'Edit Kontrak Sewa'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<int>(
                  value: _selectedTenantId,
                  decoration: const InputDecoration(
                    labelText: 'Penyewa',
                  ),
                  items: _tenants.map((tenant) {
                    return DropdownMenuItem<int>(
                      value: tenant.id,
                      child: Text(tenant.name),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedTenantId = value;
                    });
                  },
                  validator: (value) {
                    if (value == null) {
                      return 'Pilih penyewa';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<int>(
                  value: _selectedRoomId,
                  decoration: const InputDecoration(
                    labelText: 'Kamar',
                  ),
                  items: _rooms.map((room) {
                    return DropdownMenuItem<int>(
                      value: room.id,
                      child: Text('Kamar ${room.roomNumber} - ${_currencyFormat.format(room.price)}'),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedRoomId = value;
                      // Update harga sesuai kamar yang dipilih
                      if (value != null) {
                        final room = _rooms.firstWhere((room) => room.id == value);
                        _priceController.text = room.price.toString();
                      }
                    });
                  },
                  validator: (value) {
                    if (value == null) {
                      return 'Pilih kamar';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        readOnly: true,
                        decoration: const InputDecoration(
                          labelText: 'Tanggal Mulai',
                        ),
                        controller: TextEditingController(
                          text: _dateFormat.format(_startDate),
                        ),
                        onTap: () => _selectDate(context, true),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.calendar_today),
                      onPressed: () => _selectDate(context, true),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        readOnly: true,
                        decoration: const InputDecoration(
                          labelText: 'Tanggal Selesai',
                        ),
                        controller: TextEditingController(
                          text: _dateFormat.format(_endDate),
                        ),
                        onTap: () => _selectDate(context, false),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.calendar_today),
                      onPressed: () => _selectDate(context, false),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _priceController,
                  decoration: const InputDecoration(
                    labelText: 'Harga Sewa',
                    prefixText: 'Rp ',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Harga sewa tidak boleh kosong';
                    }
                    if (double.tryParse(value) == null) {
                      return 'Harga sewa harus berupa angka';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                try {
                  final rental = Rental(
                    id: _selectedRental?.id,
                    tenantId: _selectedTenantId!,
                    roomId: _selectedRoomId!,
                    startDate: _startDate.toIso8601String(),
                    endDate: _endDate.toIso8601String(),
                    rentPrice: double.parse(_priceController.text),
                    status: _selectedRental?.status ?? 'active',
                  );
                  
                  if (_selectedRental == null) {
                    await _rentalRepository.insertRental(rental);
                    // Update status kamar menjadi 'rented'
                    await _roomRepository.updateRoomStatus(_selectedRoomId!, 'rented');
                  } else {
                    await _rentalRepository.updateRental(rental);
                  }
                  
                  Navigator.pop(context);
                  _loadData();
                  
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        _selectedRental == null
                            ? 'Kontrak sewa berhasil ditambahkan'
                            : 'Kontrak sewa berhasil diperbarui',
                      ),
                      backgroundColor: Colors.green,
                    ),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Error: ${e.toString()}'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  void _showStatusChangeDialog(Rental rental) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Ubah Status Kontrak'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text('Aktif'),
              leading: Radio<String>(
                value: 'active',
                groupValue: rental.status,
                onChanged: (value) async {
                  await _updateRentalStatus(rental, value!);
                  Navigator.pop(context);
                },
              ),
            ),
            ListTile(
              title: const Text('Selesai'),
              leading: Radio<String>(
                value: 'ended',
                groupValue: rental.status,
                onChanged: (value) async {
                  await _updateRentalStatus(rental, value!);
                  Navigator.pop(context);
                },
              ),
            ),
            ListTile(
              title: const Text('Dibatalkan'),
              leading: Radio<String>(
                value: 'cancelled',
                groupValue: rental.status,
                onChanged: (value) async {
                  await _updateRentalStatus(rental, value!);
                  Navigator.pop(context);
                },
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
        ],
      ),
    );
  }

  Future<void> _updateRentalStatus(Rental rental, String status) async {
    try {
      await _rentalRepository.updateRentalStatus(rental.id!, status);
      
      // Jika status kontrak berubah menjadi 'ended' atau 'cancelled', update status kamar menjadi 'available'
      if (status == 'ended' || status == 'cancelled') {
        await _roomRepository.updateRoomStatus(rental.roomId, 'available');
      }
      
      _loadData();
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Status kontrak berhasil diperbarui'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  String _getTenantName(int tenantId) {
    final tenant = _tenants.firstWhere(
      (tenant) => tenant.id == tenantId,
      orElse: () => Tenant(id: 0, name: 'Unknown'),
    );
    return tenant.name;
  }

  String _getRoomNumber(int roomId) {
    final room = _rooms.firstWhere(
      (room) => room.id == roomId,
      orElse: () => Room(id: 0, ownerId: 0, roomNumber: 'Unknown', price: 0),
    );
    return room.roomNumber;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _rentals.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.assignment,
                        size: 80,
                        color: Colors.grey,
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Belum ada data kontrak sewa',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.grey,
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => _showRentalForm(),
                        child: const Text('Tambah Kontrak Sewa'),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: _rentals.length,
                  itemBuilder: (context, index) {
                    final rental = _rentals[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      child: ListTile(
                        title: Text(
                          'Kamar ${_getRoomNumber(rental.roomId)} - ${_getTenantName(rental.tenantId)}',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Periode: ${_dateFormat.format(DateTime.parse(rental.startDate))} - ${_dateFormat.format(DateTime.parse(rental.endDate))}'),
                            Text('Harga: ${_currencyFormat.format(rental.rentPrice)}'),
                            Text(
                              'Status: ${rental.status}',
                              style: TextStyle(
                                color: rental.status == 'active'
                                    ? Colors.green
                                    : rental.status == 'ended'
                                        ? Colors.blue
                                        : Colors.red,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        trailing: PopupMenuButton(
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              value: 'edit',
                              child: Text('Edit'),
                            ),
                            const PopupMenuItem(
                              value: 'status',
                              child: Text('Ubah Status'),
                            ),
                          ],
                          onSelected: (value) {
                            if (value == 'edit') {
                              _showRentalForm(rental: rental);
                            } else if (value == 'status') {
                              _showStatusChangeDialog(rental);
                            }
                          },
                        ),
                        onTap: () {
                          // Detail kontrak
                        },
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showRentalForm(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
