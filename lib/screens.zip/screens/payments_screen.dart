import 'package:flutter/material.dart';
import 'package:kosan/models/payment.dart';
import 'package:kosan/models/rental.dart';
import 'package:kosan/models/room.dart';
import 'package:kosan/models/tenant.dart';
import 'package:kosan/models/user.dart';
import 'package:kosan/repositories/payment_repository.dart';
import 'package:kosan/repositories/rental_repository.dart';
import 'package:kosan/repositories/room_repository.dart';
import 'package:kosan/repositories/tenant_repository.dart';
import 'package:kosan/screens/payment_receipt_screen.dart';
import 'package:intl/intl.dart';

class PaymentsScreen extends StatefulWidget {
  final User user;

  const PaymentsScreen({Key? key, required this.user}) : super(key: key);

  @override
  State<PaymentsScreen> createState() => _PaymentsScreenState();
}

class _PaymentsScreenState extends State<PaymentsScreen> {
  final _paymentRepository = PaymentRepository();
  final _rentalRepository = RentalRepository();
  final _roomRepository = RoomRepository();
  final _tenantRepository = TenantRepository();
  final _formKey = GlobalKey<FormState>();
  
  List<Payment> _payments = [];
  List<Rental> _rentals = [];
  List<Room> _rooms = [];
  List<Tenant> _tenants = [];
  bool _isLoading = true;
  Payment? _selectedPayment;
  
  int? _selectedRentalId;
  DateTime _paymentDate = DateTime.now();
  final _amountController = TextEditingController();
  final _paymentMethodController = TextEditingController();
  final _noteController = TextEditingController();
  
  final _dateFormat = DateFormat('dd/MM/yyyy');
  final _currencyFormat = NumberFormat.currency(
    locale: 'id',
    symbol: 'Rp ',
    decimalDigits: 0,
  );

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _amountController.dispose();
    _paymentMethodController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      final payments = await _paymentRepository.getAllPayments();
      final rentals = await _rentalRepository.getAllRentals();
      final rooms = await _roomRepository.getAllRooms();
      final tenants = await _tenantRepository.getAllTenants();
      
      setState(() {
        _payments = payments;
        _rentals = rentals;
        _rooms = rooms;
        _tenants = tenants;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _resetForm() {
    _selectedPayment = null;
    _selectedRentalId = null;
    _paymentDate = DateTime.now();
    _amountController.clear();
    _paymentMethodController.clear();
    _noteController.clear();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _paymentDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    
    if (picked != null) {
      setState(() {
        _paymentDate = picked;
      });
    }
  }

  void _showPaymentForm({Payment? payment}) {
    _resetForm();
    
    if (payment != null) {
      _selectedPayment = payment;
      _selectedRentalId = payment.rentalId;
      _paymentDate = DateTime.parse(payment.paymentDate);
      _amountController.text = payment.amount.toString();
      _paymentMethodController.text = payment.paymentMethod ?? '';
      _noteController.text = payment.note ?? '';
    } else {
      // Default untuk kontrak yang dipilih
      if (_rentals.isNotEmpty) {
        _selectedRentalId = _rentals.first.id;
        _amountController.text = _rentals.first.rentPrice.toString();
      }
    }
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(payment == null ? 'Tambah Pembayaran' : 'Edit Pembayaran'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<int>(
                  value: _selectedRentalId,
                  decoration: const InputDecoration(
                    labelText: 'Kontrak Sewa',
                  ),
                  items: _rentals.map((rental) {
                    final tenant = _tenants.firstWhere(
                      (tenant) => tenant.id == rental.tenantId,
                      orElse: () => Tenant(id: 0, name: 'Unknown'),
                    );
                    final room = _rooms.firstWhere(
                      (room) => room.id == rental.roomId,
                      orElse: () => Room(id: 0, ownerId: 0, roomNumber: 'Unknown', price: 0),
                    );
                    return DropdownMenuItem<int>(
                      value: rental.id,
                      child: Text('${tenant.name} - Kamar ${room.roomNumber}'),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedRentalId = value;
                      // Update jumlah sesuai harga sewa
                      if (value != null) {
                        final rental = _rentals.firstWhere((rental) => rental.id == value);
                        _amountController.text = rental.rentPrice.toString();
                      }
                    });
                  },
                  validator: (value) {
                    if (value == null) {
                      return 'Pilih kontrak sewa';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        readOnly: true,
                        decoration: const InputDecoration(
                          labelText: 'Tanggal Pembayaran',
                        ),
                        controller: TextEditingController(
                          text: _dateFormat.format(_paymentDate),
                        ),
                        onTap: () => _selectDate(context),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.calendar_today),
                      onPressed: () => _selectDate(context),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _amountController,
                  decoration: const InputDecoration(
                    labelText: 'Jumlah Pembayaran',
                    prefixText: 'Rp ',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Jumlah pembayaran tidak boleh kosong';
                    }
                    if (double.tryParse(value) == null) {
                      return 'Jumlah pembayaran harus berupa angka';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _paymentMethodController,
                  decoration: const InputDecoration(
                    labelText: 'Metode Pembayaran',
                  ),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _noteController,
                  decoration: const InputDecoration(
                    labelText: 'Catatan',
                  ),
                  maxLines: 2,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                try {
                  final payment = Payment(
                    id: _selectedPayment?.id,
                    rentalId: _selectedRentalId!,
                    paymentDate: _paymentDate.toIso8601String(),
                    amount: double.parse(_amountController.text),
                    paymentMethod: _paymentMethodController.text.isNotEmpty ? _paymentMethodController.text : null,
                    note: _noteController.text.isNotEmpty ? _noteController.text : null,
                  );
                  
                  late Payment savedPayment;
                  
                  if (_selectedPayment == null) {
                    // Insert new payment
                    final paymentId = await _paymentRepository.insertPayment(payment);
                    final newPayment = await _paymentRepository.getPaymentById(paymentId);
                    if (newPayment != null) {
                      savedPayment = newPayment;
                    } else {
                      savedPayment = payment;
                    }
                  } else {
                    // Update existing payment
                    await _paymentRepository.updatePayment(payment);
                    savedPayment = payment;
                  }
                  
                  Navigator.pop(context);
                  _loadData();
                  
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        _selectedPayment == null
                            ? 'Pembayaran berhasil ditambahkan'
                            : 'Pembayaran berhasil diperbarui',
                      ),
                      backgroundColor: Colors.green,
                    ),
                  );
                  
                  // Jika ini adalah pembayaran baru, tampilkan struk
                  if (_selectedPayment == null) {
                    // Tampilkan struk pembayaran
                    if (!mounted) return;
                    _showReceiptDialog(savedPayment);
                  }
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Error: ${e.toString()}'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  void _showReceiptDialog(Payment payment) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Pembayaran Berhasil'),
        content: const Text('Pembayaran telah berhasil disimpan. Apakah Anda ingin melihat struk pembayaran?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tidak'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _viewReceipt(payment);
            },
            child: const Text('Lihat Struk'),
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirmation(Payment payment) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Pembayaran'),
        content: const Text('Apakah Anda yakin ingin menghapus pembayaran ini?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              try {
                await _paymentRepository.deletePayment(payment.id!);
                Navigator.pop(context);
                _loadData();
                
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Pembayaran berhasil dihapus'),
                    backgroundColor: Colors.green,
                  ),
                );
              } catch (e) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Error: ${e.toString()}'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }

  String _getRentalInfo(int rentalId) {
    final rental = _rentals.firstWhere(
      (rental) => rental.id == rentalId,
      orElse: () => Rental(
        id: 0,
        tenantId: 0,
        roomId: 0,
        startDate: '',
        endDate: '',
        rentPrice: 0,
      ),
    );
    
    if (rental.id == 0) return 'Unknown';
    
    final tenant = _tenants.firstWhere(
      (tenant) => tenant.id == rental.tenantId,
      orElse: () => Tenant(id: 0, name: 'Unknown'),
    );
    
    final room = _rooms.firstWhere(
      (room) => room.id == rental.roomId,
      orElse: () => Room(id: 0, ownerId: 0, roomNumber: 'Unknown', price: 0),
    );
    
    return '${tenant.name} - Kamar ${room.roomNumber}';
  }

  void _viewReceipt(Payment payment) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PaymentReceiptScreen(
          payment: payment,
          ownerId: widget.user.ownerId ?? 0,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _payments.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.payment,
                        size: 80,
                        color: Colors.grey,
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Belum ada data pembayaran',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.grey,
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => _showPaymentForm(),
                        child: const Text('Tambah Pembayaran'),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: _payments.length,
                  itemBuilder: (context, index) {
                    final payment = _payments[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      child: Column(
                        children: [
                          ListTile(
                            title: Text(
                              _getRentalInfo(payment.rentalId),
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Tanggal: ${_dateFormat.format(DateTime.parse(payment.paymentDate))}'),
                                Text('Jumlah: ${_currencyFormat.format(payment.amount)}'),
                                if (payment.paymentMethod != null && payment.paymentMethod!.isNotEmpty)
                                  Text('Metode: ${payment.paymentMethod}'),
                                if (payment.note != null && payment.note!.isNotEmpty)
                                  Text('Catatan: ${payment.note}'),
                              ],
                            ),
                            trailing: PopupMenuButton(
                              itemBuilder: (context) => [
                                const PopupMenuItem(
                                  value: 'receipt',
                                  child: Text('Lihat Struk'),
                                ),
                                const PopupMenuItem(
                                  value: 'edit',
                                  child: Text('Edit'),
                                ),
                                const PopupMenuItem(
                                  value: 'delete',
                                  child: Text('Hapus'),
                                ),
                              ],
                              onSelected: (value) {
                                if (value == 'receipt') {
                                  _viewReceipt(payment);
                                } else if (value == 'edit') {
                                  _showPaymentForm(payment: payment);
                                } else if (value == 'delete') {
                                  _showDeleteConfirmation(payment);
                                }
                              },
                            ),
                            onTap: () {
                              _viewReceipt(payment);
                            },
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                              left: 16.0,
                              right: 16.0,
                              bottom: 8.0,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                TextButton.icon(
                                  icon: const Icon(Icons.receipt),
                                  label: const Text('Lihat Struk'),
                                  onPressed: () => _viewReceipt(payment),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showPaymentForm(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
