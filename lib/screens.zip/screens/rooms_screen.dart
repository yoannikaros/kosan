import 'package:flutter/material.dart';
import 'package:kosan/models/room.dart';
import 'package:kosan/models/user.dart';
import 'package:kosan/repositories/room_repository.dart';
import 'package:kosan/screens/facility_screen.dart';
import 'package:intl/intl.dart';

class RoomsScreen extends StatefulWidget {
  final User user;

  const RoomsScreen({Key? key, required this.user}) : super(key: key);

  @override
  State<RoomsScreen> createState() => _RoomsScreenState();
}

class _RoomsScreenState extends State<RoomsScreen> {
  final _roomRepository = RoomRepository();
  final _formKey = GlobalKey<FormState>();
  final _roomNumberController = TextEditingController();
  final _floorController = TextEditingController();
  final _priceController = TextEditingController();
  final _descriptionController = TextEditingController();
  
  List<Room> _rooms = [];
  bool _isLoading = true;
  Room? _selectedRoom;
  
  final _currencyFormat = NumberFormat.currency(
    locale: 'id',
    symbol: 'Rp ',
    decimalDigits: 0,
  );

  @override
  void initState() {
    super.initState();
    _loadRooms();
  }

  @override
  void dispose() {
    _roomNumberController.dispose();
    _floorController.dispose();
    _priceController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _loadRooms() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      final rooms = await _roomRepository.getAllRooms();
      setState(() {
        _rooms = rooms;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _resetForm() {
    _selectedRoom = null;
    _roomNumberController.clear();
    _floorController.clear();
    _priceController.clear();
    _descriptionController.clear();
  }

  void _showRoomForm({Room? room}) {
    _resetForm();
    
    if (room != null) {
      _selectedRoom = room;
      _roomNumberController.text = room.roomNumber;
      _floorController.text = room.floor?.toString() ?? '';
      _priceController.text = room.price.toString();
      _descriptionController.text = room.description ?? '';
    }
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(room == null ? 'Tambah Kamar' : 'Edit Kamar'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _roomNumberController,
                  decoration: const InputDecoration(
                    labelText: 'Nomor Kamar',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Nomor kamar tidak boleh kosong';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  controller: _floorController,
                  decoration: const InputDecoration(
                    labelText: 'Lantai',
                  ),
                  keyboardType: TextInputType.number,
                ),
                TextFormField(
                  controller: _priceController,
                  decoration: const InputDecoration(
                    labelText: 'Harga Sewa',
                    prefixText: 'Rp ',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Harga sewa tidak boleh kosong';
                    }
                    if (double.tryParse(value) == null) {
                      return 'Harga sewa harus berupa angka';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  controller: _descriptionController,
                  decoration: const InputDecoration(
                    labelText: 'Deskripsi',
                  ),
                  maxLines: 3,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                try {
                  final room = Room(
                    id: _selectedRoom?.id,
                    ownerId: widget.user.ownerId ?? 0,
                    roomNumber: _roomNumberController.text,
                    floor: _floorController.text.isNotEmpty
                        ? int.parse(_floorController.text)
                        : null,
                    price: double.parse(_priceController.text),
                    description: _descriptionController.text,
                    status: _selectedRoom?.status ?? 'available',
                  );
                  
                  if (_selectedRoom == null) {
                    await _roomRepository.insertRoom(room);
                  } else {
                    await _roomRepository.updateRoom(room);
                  }
                  
                  Navigator.pop(context);
                  _loadRooms();
                  
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        _selectedRoom == null
                            ? 'Kamar berhasil ditambahkan'
                            : 'Kamar berhasil diperbarui',
                      ),
                      backgroundColor: Colors.green,
                    ),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Error: ${e.toString()}'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirmation(Room room) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Kamar'),
        content: Text('Apakah Anda yakin ingin menghapus kamar ${room.roomNumber}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              try {
                await _roomRepository.deleteRoom(room.id!);
                Navigator.pop(context);
                _loadRooms();
                
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Kamar berhasil dihapus'),
                    backgroundColor: Colors.green,
                  ),
                );
              } catch (e) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Error: ${e.toString()}'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }

  void _navigateToFacilities(Room room) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => FacilityScreen(
          user: widget.user,
          roomId: room.id!,
          roomNumber: room.roomNumber,
        ),
      ),
    ).then((_) => _loadRooms());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _rooms.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.meeting_room,
                        size: 80,
                        color: Colors.grey,
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Belum ada data kamar',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.grey,
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => _showRoomForm(),
                        child: const Text('Tambah Kamar'),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: _rooms.length,
                  itemBuilder: (context, index) {
                    final room = _rooms[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      child: Column(
                        children: [
                          ListTile(
                            title: Text(
                              'Kamar ${room.roomNumber}',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Harga: ${_currencyFormat.format(room.price)}'),
                                if (room.floor != null) Text('Lantai: ${room.floor}'),
                                Text('Status: ${room.status}'),
                              ],
                            ),
                            trailing: PopupMenuButton(
                              itemBuilder: (context) => [
                                const PopupMenuItem(
                                  value: 'edit',
                                  child: Text('Edit'),
                                ),
                                const PopupMenuItem(
                                  value: 'delete',
                                  child: Text('Hapus'),
                                ),
                                const PopupMenuItem(
                                  value: 'facilities',
                                  child: Text('Kelola Fasilitas'),
                                ),
                              ],
                              onSelected: (value) {
                                if (value == 'edit') {
                                  _showRoomForm(room: room);
                                } else if (value == 'delete') {
                                  _showDeleteConfirmation(room);
                                } else if (value == 'facilities') {
                                  _navigateToFacilities(room);
                                }
                              },
                            ),
                            onTap: () {
                              // Detail kamar
                            },
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                              left: 16.0,
                              right: 16.0,
                              bottom: 8.0,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                TextButton.icon(
                                  icon: const Icon(Icons.chair),
                                  label: const Text('Fasilitas'),
                                  onPressed: () => _navigateToFacilities(room),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showRoomForm(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
