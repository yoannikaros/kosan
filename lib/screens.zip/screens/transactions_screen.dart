import 'package:flutter/material.dart';
import 'package:kosan/models/transaction.dart';
import 'package:kosan/models/user.dart';
import 'package:kosan/repositories/transaction_repository.dart';
import 'package:intl/intl.dart';

class TransactionsScreen extends StatefulWidget {
  final User user;

  const TransactionsScreen({Key? key, required this.user}) : super(key: key);

  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  final _transactionRepository = TransactionRepository();
  final _formKey = GlobalKey<FormState>();
  
  List<Transaction> _transactions = [];
  bool _isLoading = true;
  Transaction? _selectedTransaction;
  
  String _selectedType = 'income';
  final _categoryController = TextEditingController();
  final _amountController = TextEditingController();
  final _descriptionController = TextEditingController();
  DateTime _transactionDate = DateTime.now();
  
  final _dateFormat = DateFormat('dd/MM/yyyy');
  final _currencyFormat = NumberFormat.currency(
    locale: 'id',
    symbol: 'Rp ',
    decimalDigits: 0,
  );

  @override
  void initState() {
    super.initState();
    _loadTransactions();
  }

  @override
  void dispose() {
    _categoryController.dispose();
    _amountController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _loadTransactions() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      final transactions = await _transactionRepository.getAllTransactions();
      setState(() {
        _transactions = transactions;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _resetForm() {
    _selectedTransaction = null;
    _selectedType = 'income';
    _categoryController.clear();
    _amountController.clear();
    _descriptionController.clear();
    _transactionDate = DateTime.now();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _transactionDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    
    if (picked != null) {
      setState(() {
        _transactionDate = picked;
      });
    }
  }

  void _showTransactionForm({Transaction? transaction}) {
    _resetForm();
    
    if (transaction != null) {
      _selectedTransaction = transaction;
      _selectedType = transaction.type;
      _categoryController.text = transaction.category ?? '';
      _amountController.text = transaction.amount.toString();
      _descriptionController.text = transaction.description ?? '';
      _transactionDate = DateTime.parse(transaction.transactionDate);
    }
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(transaction == null ? 'Tambah Transaksi' : 'Edit Transaksi'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: _selectedType,
                  decoration: const InputDecoration(
                    labelText: 'Tipe Transaksi',
                  ),
                  items: const [
                    DropdownMenuItem<String>(
                      value: 'income',
                      child: Text('Pemasukan'),
                    ),
                    DropdownMenuItem<String>(
                      value: 'expense',
                      child: Text('Pengeluaran'),
                    ),
                  ],
                  onChanged: (value) {
                    setState(() {
                      _selectedType = value!;
                    });
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _categoryController,
                  decoration: const InputDecoration(
                    labelText: 'Kategori',
                  ),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _amountController,
                  decoration: const InputDecoration(
                    labelText: 'Jumlah',
                    prefixText: 'Rp ',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Jumlah tidak boleh kosong';
                    }
                    if (double.tryParse(value) == null) {
                      return 'Jumlah harus berupa angka';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _descriptionController,
                  decoration: const InputDecoration(
                    labelText: 'Deskripsi',
                  ),
                  maxLines: 2,
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        readOnly: true,
                        decoration: const InputDecoration(
                          labelText: 'Tanggal Transaksi',
                        ),
                        controller: TextEditingController(
                          text: _dateFormat.format(_transactionDate),
                        ),
                        onTap: () => _selectDate(context),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.calendar_today),
                      onPressed: () => _selectDate(context),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                try {
                  final transaction = Transaction(
                    id: _selectedTransaction?.id,
                    ownerId: widget.user.ownerId ?? 0,
                    type: _selectedType,
                    category: _categoryController.text.isNotEmpty ? _categoryController.text : null,
                    amount: double.parse(_amountController.text),
                    description: _descriptionController.text.isNotEmpty ? _descriptionController.text : null,
                    transactionDate: _transactionDate.toIso8601String(),
                  );
                  
                  if (_selectedTransaction == null) {
                    await _transactionRepository.insertTransaction(transaction);
                  } else {
                    await _transactionRepository.updateTransaction(transaction);
                  }
                  
                  Navigator.pop(context);
                  _loadTransactions();
                  
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        _selectedTransaction == null
                            ? 'Transaksi berhasil ditambahkan'
                            : 'Transaksi berhasil diperbarui',
                      ),
                      backgroundColor: Colors.green,
                    ),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Error: ${e.toString()}'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirmation(Transaction transaction) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Transaksi'),
        content: const Text('Apakah Anda yakin ingin menghapus transaksi ini?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              try {
                await _transactionRepository.deleteTransaction(transaction.id!);
                Navigator.pop(context);
                _loadTransactions();
                
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Transaksi berhasil dihapus'),
                    backgroundColor: Colors.green,
                  ),
                );
              } catch (e) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Error: ${e.toString()}'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _transactions.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.account_balance_wallet,
                        size: 80,
                        color: Colors.grey,
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Belum ada data transaksi',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.grey,
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => _showTransactionForm(),
                        child: const Text('Tambah Transaksi'),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: _transactions.length,
                  itemBuilder: (context, index) {
                    final transaction = _transactions[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: transaction.type == 'income' ? Colors.green : Colors.red,
                          child: Icon(
                            transaction.type == 'income' ? Icons.arrow_downward : Icons.arrow_upward,
                            color: Colors.white,
                          ),
                        ),
                        title: Text(
                          transaction.category ?? (transaction.type == 'income' ? 'Pemasukan' : 'Pengeluaran'),
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Tanggal: ${_dateFormat.format(DateTime.parse(transaction.transactionDate))}'),
                            if (transaction.description != null)
                              Text('Deskripsi: ${transaction.description}'),
                          ],
                        ),
                        trailing: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              _currencyFormat.format(transaction.amount),
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: transaction.type == 'income' ? Colors.green : Colors.red,
                              ),
                            ),
                            PopupMenuButton(
                              itemBuilder: (context) => [
                                const PopupMenuItem(
                                  value: 'edit',
                                  child: Text('Edit'),
                                ),
                                const PopupMenuItem(
                                  value: 'delete',
                                  child: Text('Hapus'),
                                ),
                              ],
                              onSelected: (value) {
                                if (value == 'edit') {
                                  _showTransactionForm(transaction: transaction);
                                } else if (value == 'delete') {
                                  _showDeleteConfirmation(transaction);
                                }
                              },
                            ),
                          ],
                        ),
                        onTap: () {
                          // Detail transaksi
                        },
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showTransactionForm(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
