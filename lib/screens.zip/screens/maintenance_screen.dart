import 'package:flutter/material.dart';
import 'package:kosan/models/maintenance.dart';
import 'package:kosan/models/room.dart';
import 'package:kosan/models/user.dart';
import 'package:kosan/repositories/maintenance_repository.dart';
import 'package:kosan/repositories/room_repository.dart';
import 'package:intl/intl.dart';

class MaintenanceScreen extends StatefulWidget {
  final User user;

  const MaintenanceScreen({Key? key, required this.user}) : super(key: key);

  @override
  State<MaintenanceScreen> createState() => _MaintenanceScreenState();
}

class _MaintenanceScreenState extends State<MaintenanceScreen> {
  final _maintenanceRepository = MaintenanceRepository();
  final _roomRepository = RoomRepository();
  final _formKey = GlobalKey<FormState>();
  
  List<Maintenance> _maintenances = [];
  List<Room> _rooms = [];
  bool _isLoading = true;
  Maintenance? _selectedMaintenance;
  
  int? _selectedRoomId;
  final _descriptionController = TextEditingController();
  final _costController = TextEditingController();
  DateTime _maintenanceDate = DateTime.now();
  
  final _dateFormat = DateFormat('dd/MM/yyyy');
  final _currencyFormat = NumberFormat.currency(
    locale: 'id',
    symbol: 'Rp ',
    decimalDigits: 0,
  );

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _descriptionController.dispose();
    _costController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      final maintenances = await _maintenanceRepository.getAllMaintenance();
      final rooms = await _roomRepository.getAllRooms();
      
      setState(() {
        _maintenances = maintenances;
        _rooms = rooms;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _resetForm() {
    _selectedMaintenance = null;
    _selectedRoomId = null;
    _descriptionController.clear();
    _costController.clear();
    _maintenanceDate = DateTime.now();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _maintenanceDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    
    if (picked != null) {
      setState(() {
        _maintenanceDate = picked;
      });
    }
  }

  void _showMaintenanceForm({Maintenance? maintenance}) {
    _resetForm();
    
    if (maintenance != null) {
      _selectedMaintenance = maintenance;
      _selectedRoomId = maintenance.roomId;
      _descriptionController.text = maintenance.description;
      _costController.text = maintenance.cost?.toString() ?? '';
      _maintenanceDate = DateTime.parse(maintenance.maintenanceDate);
    } else {
      // Default untuk kamar yang dipilih
      if (_rooms.isNotEmpty) {
        _selectedRoomId = _rooms.first.id;
      }
    }
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(maintenance == null ? 'Tambah Perawatan' : 'Edit Perawatan'),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<int>(
                  value: _selectedRoomId,
                  decoration: const InputDecoration(
                    labelText: 'Kamar',
                  ),
                  items: _rooms.map((room) {
                    return DropdownMenuItem<int>(
                      value: room.id,
                      child: Text('Kamar ${room.roomNumber}'),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedRoomId = value;
                    });
                  },
                  validator: (value) {
                    if (value == null) {
                      return 'Pilih kamar';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _descriptionController,
                  decoration: const InputDecoration(
                    labelText: 'Deskripsi Perawatan',
                  ),
                  maxLines: 3,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Deskripsi tidak boleh kosong';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _costController,
                  decoration: const InputDecoration(
                    labelText: 'Biaya Perawatan',
                    prefixText: 'Rp ',
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        readOnly: true,
                        decoration: const InputDecoration(
                          labelText: 'Tanggal Perawatan',
                        ),
                        controller: TextEditingController(
                          text: _dateFormat.format(_maintenanceDate),
                        ),
                        onTap: () => _selectDate(context),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.calendar_today),
                      onPressed: () => _selectDate(context),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                try {
                  final maintenance = Maintenance(
                    id: _selectedMaintenance?.id,
                    roomId: _selectedRoomId!,
                    description: _descriptionController.text,
                    cost: _costController.text.isNotEmpty ? double.parse(_costController.text) : null,
                    maintenanceDate: _maintenanceDate.toIso8601String(),
                  );
                  
                  if (_selectedMaintenance == null) {
                    await _maintenanceRepository.insertMaintenance(maintenance);
                  } else {
                    await _maintenanceRepository.updateMaintenance(maintenance);
                  }
                  
                  Navigator.pop(context);
                  _loadData();
                  
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        _selectedMaintenance == null
                            ? 'Perawatan berhasil ditambahkan'
                            : 'Perawatan berhasil diperbarui',
                      ),
                      backgroundColor: Colors.green,
                    ),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Error: ${e.toString()}'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirmation(Maintenance maintenance) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Perawatan'),
        content: const Text('Apakah Anda yakin ingin menghapus data perawatan ini?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              try {
                await _maintenanceRepository.deleteMaintenance(maintenance.id!);
                Navigator.pop(context);
                _loadData();
                
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Perawatan berhasil dihapus'),
                    backgroundColor: Colors.green,
                  ),
                );
              } catch (e) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Error: ${e.toString()}'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }

  String _getRoomNumber(int roomId) {
    final room = _rooms.firstWhere(
      (room) => room.id == roomId,
      orElse: () => Room(id: 0, ownerId: 0, roomNumber: 'Unknown', price: 0),
    );
    return room.roomNumber;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _maintenances.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.build,
                        size: 80,
                        color: Colors.grey,
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Belum ada data perawatan',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.grey,
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => _showMaintenanceForm(),
                        child: const Text('Tambah Perawatan'),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: _maintenances.length,
                  itemBuilder: (context, index) {
                    final maintenance = _maintenances[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      child: ListTile(
                        title: Text(
                          'Kamar ${_getRoomNumber(maintenance.roomId)}',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Tanggal: ${_dateFormat.format(DateTime.parse(maintenance.maintenanceDate))}'),
                            Text('Deskripsi: ${maintenance.description}'),
                            if (maintenance.cost != null)
                              Text('Biaya: ${_currencyFormat.format(maintenance.cost)}'),
                          ],
                        ),
                        trailing: PopupMenuButton(
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              value: 'edit',
                              child: Text('Edit'),
                            ),
                            const PopupMenuItem(
                              value: 'delete',
                              child: Text('Hapus'),
                            ),
                          ],
                          onSelected: (value) {
                            if (value == 'edit') {
                              _showMaintenanceForm(maintenance: maintenance);
                            } else if (value == 'delete') {
                              _showDeleteConfirmation(maintenance);
                            }
                          },
                        ),
                        onTap: () {
                          // Detail perawatan
                        },
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showMaintenanceForm(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
